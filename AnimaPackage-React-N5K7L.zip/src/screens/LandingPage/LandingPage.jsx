import React from "react";
import { InputCognome } from "../../components/InputCognome";
import { InputEmail } from "../../components/InputEmail";
import { InputNome } from "../../components/InputNome";
import { InputPassword } from "../../components/InputPassword";
import { Pulsante } from "../../components/Pulsante";
import { SmartbudgetLogo } from "../../components/SmartbudgetLogo";
import "./style.css";

export const LandingPage = () => {
  return (
    <div className="landing-page">
      <div className="div-2">
        <div className="text-wrapper-6">Hai già un account?</div>
        <div className="text-wrapper-7">Accedi</div>
        <p className="p">Crea un account per iniziare</p>
        <div className="text-wrapper-8">Benvenuto!</div>
        <div className="form">
          <Pulsante className="pulsante-registrazione" />
          <InputPassword className="input-password-instance" />
          <InputEmail className="input-email-instance" />
          <InputNome className="input-nome-instance" />
          <InputCognome className="input-cognome-instance" />
        </div>
        <SmartbudgetLogo
          className="smartbudget-logo-instance"
          divClassName="design-component-instance-node"
          icon="/img/icon-1.png"
        />
      </div>
    </div>
  );
};
