export { InputNome } from "./InputNome";
