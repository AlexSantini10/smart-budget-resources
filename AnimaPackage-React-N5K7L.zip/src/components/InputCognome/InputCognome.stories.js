import { InputCognome } from ".";

export default {
  title: "Components/InputCognome",
  component: InputCognome,
};

export const Default = {
  args: {
    className: {},
  },
};
