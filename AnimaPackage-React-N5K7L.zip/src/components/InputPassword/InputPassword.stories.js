import { InputPassword } from ".";

export default {
  title: "Components/InputPassword",
  component: InputPassword,
};

export const Default = {
  args: {
    className: {},
  },
};
