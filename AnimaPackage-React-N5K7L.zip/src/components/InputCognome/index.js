export { InputCognome } from "./InputCognome";
