import { InputEmail } from ".";

export default {
  title: "Components/InputEmail",
  component: InputEmail,
};

export const Default = {
  args: {
    className: {},
  },
};
