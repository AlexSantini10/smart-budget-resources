import { InputNome } from ".";

export default {
  title: "Components/InputNome",
  component: InputNome,
};

export const Default = {
  args: {
    className: {},
  },
};
