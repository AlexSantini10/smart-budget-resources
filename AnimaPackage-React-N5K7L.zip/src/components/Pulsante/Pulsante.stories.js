import { Pulsante } from ".";

export default {
  title: "Components/Pulsante",
  component: Pulsante,
};

export const Default = {
  args: {
    className: {},
  },
};
