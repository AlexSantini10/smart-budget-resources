import { SmartbudgetLogo } from ".";

export default {
  title: "Components/SmartbudgetLogo",
  component: SmartbudgetLogo,
};

export const Default = {
  args: {
    className: {},
    icon: "/img/icon.png",
    divClassName: {},
  },
};
