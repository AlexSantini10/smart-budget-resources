export { InputPassword } from "./InputPassword";
